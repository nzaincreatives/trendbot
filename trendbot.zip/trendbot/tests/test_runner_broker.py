import math
import re

import pytest
from fastapi.testclient import TestClient

from bot.broker import CcxtBroker, OrderRejected
from bot.dashboard import create_app
from bot.runner import Runner
from bot.store import Store

from conftest import TF_MS, candles, down_up_down


# ---------- Fake-Börsen (kein Netzwerk) ----------
class FakeTradeEx:
    """Minimal-Attrappe einer ccxt-Börse für den CcxtBroker."""

    def __init__(self, btc_free=0.0, fee_ccy="BTC"):
        self.m = {"base": "BTC", "quote": "USDT",
                  "limits": {"cost": {"min": 5.0}, "amount": {"min": 0.00001}}}
        self.balance = {"free": {"USDT": 100.0, "BTC": btc_free}}
        self.orders = []
        self.fee_ccy = fee_ccy

    def load_markets(self): pass
    def market(self, symbol): return self.m
    def amount_to_precision(self, symbol, a): return str(math.floor(a * 1e5) / 1e5)
    def fetch_balance(self): return self.balance

    def create_order(self, symbol, typ, side, amount, price=None):
        px = price or 50_000.0
        self.orders.append((side, amount))
        fee = {"currency": self.fee_ccy, "cost": amount * 0.001 if self.fee_ccy == "BTC" else 0.002}
        return {"id": str(len(self.orders)), "status": "closed", "filled": amount, "average": px,
                "cost": amount * px, "fees": [fee]}


def test_ccxt_buy_rounds_down_and_handles_base_fee():
    ex = FakeTradeEx()
    b = CcxtBroker("binance", "BTC/USDT", {}, exchange=ex)
    fill = b.market_buy(9.0, 50_000.0)
    assert ex.orders == [("buy", 0.00017)]                     # abgerundet, mit 0,5 % Puffer
    assert fill.amount == pytest.approx(0.00017 * 0.999)       # Gebühr in BTC verringert die Menge
    assert fill.net_quote == pytest.approx(0.00017 * 50_000)   # USDT-Seite: nur der Kaufpreis


def test_ccxt_rejects_below_exchange_minimum():
    b = CcxtBroker("binance", "BTC/USDT", {}, exchange=FakeTradeEx())
    with pytest.raises(OrderRejected):
        b.market_buy(4.0, 50_000.0)
    with pytest.raises(OrderRejected):
        b.market_sell(0.00005, 50_000.0)                       # Wert 2,5 USDT -> unter Minimum


def test_ccxt_sell_never_exceeds_free_balance():
    ex = FakeTradeEx(btc_free=0.00016983)
    b = CcxtBroker("binance", "BTC/USDT", {}, exchange=ex)
    b.market_sell(0.00017, 50_000.0)
    assert ex.orders == [("sell", 0.00016)]


def test_ccxt_unknown_fee_currency_is_estimated():
    b = CcxtBroker("binance", "BTC/USDT", {}, exchange=FakeTradeEx(fee_ccy="BNB"))
    fill = b.market_buy(9.0, 50_000.0)
    assert fill.fee == pytest.approx(fill.cost * 0.001)
    assert fill.net_quote == pytest.approx(fill.cost * 1.001)


def test_missing_keys_stop_live_start():
    with pytest.raises(RuntimeError):
        CcxtBroker("binance", "BTC/USDT", {})


# ---------- Runner mit simulierter Zeit ----------
class FakePublicEx:
    def __init__(self, df):
        self.df = df
        self.k = 0

    def parse_timeframe(self, tf): return TF_MS // 1000

    def fetch_ohlcv(self, symbol, tf, since=None, limit=None):
        part = self.df.iloc[max(0, self.k - (limit or 100) + 1): self.k + 1]
        return part[["ts", "open", "high", "low", "close", "volume"]].values.tolist()


def make_runner(cfg, tmp_path, df, name="s.sqlite3", store=None):
    ex = FakePublicEx(df)
    now = {"t": 0.0}
    r = Runner(cfg, public_exchange=ex, store=store or Store(tmp_path / name), clock=lambda: now["t"])
    return r, ex, now


def drive(r, ex, now, df, start, stop):
    for k in range(start, stop):
        ex.k = k
        now["t"] = (int(df["ts"].iloc[k]) + TF_MS // 2) / 1000   # mitten in Kerze k (sie läuft noch)
        r.step()


def test_runner_trades_a_full_cycle_and_never_enters_mid_trend(cfg, tmp_path):
    df = candles(down_up_down())
    r, ex, now = make_runner(cfg, tmp_path, df)
    drive(r, ex, now, df, 40, len(df))
    trades = r.store.trades(100)[::-1]
    sides = [t["side"] for t in trades]
    assert sides[:2] == ["buy", "sell"], sides
    assert sum(t["pnl"] for t in trades if t["pnl"] is not None) > 0
    assert r.trader.state.cash > cfg.start_equity

    # Start mitten im Aufwärtstrend -> darf NICHT sofort einsteigen
    r2, ex2, now2 = make_runner(cfg, tmp_path, df, name="mid.sqlite3")
    drive(r2, ex2, now2, df, 90, 100)
    assert not r2.trader.has_position and r2.trader.state.armed is False


def test_runner_restores_state_after_restart(cfg, tmp_path):
    df = candles(down_up_down())
    store = Store(tmp_path / "persist.sqlite3")
    r, ex, now = make_runner(cfg, tmp_path, df, store=store)
    drive(r, ex, now, df, 40, 100)                   # mitten im Aufwärtstrend, Position offen
    assert r.trader.has_position
    pos = dict(r.trader.state.position)

    r2, ex2, now2 = make_runner(cfg, tmp_path, df, store=store)
    assert r2.trader.state.position == pos
    assert r2.trader.state.cash == pytest.approx(r.trader.state.cash)


def test_runner_ignores_forming_candle(cfg, tmp_path):
    df = candles(down_up_down())
    r, ex, now = make_runner(cfg, tmp_path, df)
    drive(r, ex, now, df, 40, 45)
    assert r.trader.state.last_candle_ts == int(df["ts"].iloc[44]) - TF_MS   # Kerze 44 läuft noch


# ---------- Dashboard ----------
def test_dashboard_api_and_token_protection(cfg, tmp_path):
    df = candles(down_up_down())
    r, ex, now = make_runner(cfg, tmp_path, df)
    drive(r, ex, now, df, 40, 60)
    client = TestClient(create_app(r))

    html = client.get("/").text
    assert "__TOKEN__" not in html
    token = re.search(r'const TOKEN = "([^"]+)"', html).group(1)

    s = client.get("/api/status").json()
    assert s["mode"] == "paper" and s["halted"] is False
    assert client.get("/api/trades").status_code == 200
    assert client.get("/api/equity").status_code == 200
    assert client.get("/api/logs").status_code == 200

    assert client.post("/api/halt").status_code == 403                       # ohne Token
    assert client.post("/api/halt", headers={"X-Token": "falsch"}).status_code == 403
    assert client.post("/api/halt", headers={"X-Token": token}).status_code == 200
    assert client.get("/api/status").json()["halted"] is True
    assert client.post("/api/resume", headers={"X-Token": token}).status_code == 200
    assert client.get("/api/status").json()["halted"] is False
    assert client.post("/api/close", headers={"X-Token": token}).json() == {"ok": False}   # nichts zu schließen
