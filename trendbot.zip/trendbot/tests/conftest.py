import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.config import Config  # noqa: E402

TF_MS = 4 * 3600 * 1000


@pytest.fixture
def cfg() -> Config:
    c = Config()
    c.strategy.ema_fast, c.strategy.ema_slow, c.strategy.atr_period = 5, 10, 5
    c.strategy.min_atr_pct = 0.0
    c.runtime.history_bars = 100
    return c


def candles(closes, start_ts=1_600_000_000_000, tf_ms=TF_MS, wick=0.004) -> pd.DataFrame:
    closes = np.asarray(closes, dtype=float)
    opens = np.concatenate([[closes[0]], closes[:-1]])
    highs = np.maximum(opens, closes) * (1 + wick)
    lows = np.minimum(opens, closes) * (1 - wick)
    ts = start_ts + np.arange(len(closes), dtype="int64") * tf_ms
    return pd.DataFrame({"ts": ts, "open": opens, "high": highs, "low": lows, "close": closes,
                         "volume": np.ones(len(closes))})


def down_up_down(n_down=60, n_up=60, n_down2=60, lo=70.0, hi=160.0, start=100.0):
    a = np.linspace(start, lo, n_down)
    b = np.linspace(lo, hi, n_up + 1)[1:]
    c = np.linspace(hi, start, n_down2 + 1)[1:]
    return np.concatenate([a, b, c])
