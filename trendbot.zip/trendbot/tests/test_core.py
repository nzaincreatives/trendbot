import math

import pytest

from bot.backtest import run_backtest, split_out_of_sample
from bot.broker import OrderRejected, PaperBroker
from bot.config import Config, ConfigError, load_config, validate
from bot.data import drop_forming_candle
from bot.risk import size_quote, stop_price
from bot.store import MemoryStore, Store
from bot.strategy import add_indicators, min_bars
from bot.trader import Trader, TraderState

from conftest import TF_MS, candles, down_up_down

DAY = 86_400_000
T0 = 1_700_000_000_000


# ---------- Strategie ----------
def test_indicators_trend_flags(cfg):
    d = add_indicators(candles(down_up_down()), cfg.strategy)
    assert not d["uptrend"].iloc[50]          # im Abwärtsteil
    assert d["uptrend"].iloc[100]             # im Aufwärtsteil
    assert d["entry_ok"].iloc[100]
    assert d["atr"].iloc[min_bars(cfg.strategy):].notna().all()


# ---------- Broker / Buchhaltung ----------
def test_paper_roundtrip_costs_match_fee_and_slippage():
    b = PaperBroker(fee_rate=0.001, slippage=0.0005, min_notional=5)
    buy = b.market_buy(9.0, 100.0)
    assert buy.net_quote == pytest.approx(9.0)
    assert buy.amount * buy.price == pytest.approx(buy.cost)
    assert buy.cost * (1 + 0.001) == pytest.approx(9.0)
    sell = b.market_sell(buy.amount, 100.0)
    expected = 9.0 * (1 - 0.0005) / (1 + 0.0005) * (1 - 0.001) / (1 + 0.001)
    assert sell.net_quote == pytest.approx(expected, rel=1e-9)
    assert sell.net_quote < 9.0


def test_paper_min_notional_rejects():
    b = PaperBroker(min_notional=5)
    with pytest.raises(OrderRejected):
        b.market_buy(4.0, 100.0)
    with pytest.raises(OrderRejected):
        b.market_sell(0.04, 100.0)


# ---------- Risiko ----------
def test_size_quote_scales_with_equity_and_caps(cfg):
    r, c = cfg.risk, cfg.costs
    small = size_quote(10, 10, 100, 1.0, r, c)       # Stop ~3 % -> Anteil begrenzt
    assert small == pytest.approx(9.0)               # 90 % von 10
    bigger = size_quote(20, 20, 100, 1.0, r, c)
    assert bigger == pytest.approx(18.0)             # wächst mit dem Konto
    wide = size_quote(10, 10, 100, 4.0, r, c)        # Stop 12 % -> Risiko-Deckel greift
    assert wide == pytest.approx(10 * 0.05 / 0.12)
    assert size_quote(10, 2, 100, 1.0, r, c) < 2.0   # Bargeld-Deckel
    assert size_quote(0, 10, 100, 1.0, r, c) == 0


def test_stop_never_below_half():
    assert stop_price(100, 1000, 3) == 50


# ---------- Trader-Regeln ----------
def make_trader(cfg, min_notional=1.0):
    cfg.costs.min_notional = min_notional
    sink = MemoryStore()
    t = Trader(cfg, PaperBroker(cfg.costs.fee_rate, cfg.costs.slippage, min_notional), sink)
    t.on_tick(100.0, T0)
    return t, sink


def test_stop_intrabar_and_gap(cfg):
    t, sink = make_trader(cfg)
    assert t.enter(100.0, 2.0, T0)
    assert t.state.position["stop"] == pytest.approx(100.05 - 6.0)
    stop = t.state.position["stop"]
    assert not t.check_stop(bar_low=stop + 0.5, ref_price=99.0, ts=T0 + 1)
    assert t.check_stop(bar_low=stop - 1, ref_price=99.0, ts=T0 + 2)        # Tief reißt den Stop
    sell = [x for x in sink.trades if x["side"] == "sell"][0]
    assert sell["price"] == pytest.approx(stop * (1 - cfg.costs.slippage))   # Ausführung am Stop
    assert not t.state.armed

    t2, sink2 = make_trader(cfg)
    t2.enter(100.0, 2.0, T0)
    t2.check_stop(bar_low=80.0, ref_price=85.0, ts=T0 + 2)                   # Gap unter den Stop
    sell2 = [x for x in sink2.trades if x["side"] == "sell"][0]
    assert sell2["price"] == pytest.approx(85.0 * (1 - cfg.costs.slippage))  # am Eröffnungskurs


def test_rearm_only_after_trend_flip(cfg):
    t, _ = make_trader(cfg)
    t.state.armed = False
    assert t.decide(uptrend=True, entry_ok=True) is None
    assert t.decide(uptrend=False, entry_ok=False) is None
    assert t.state.armed
    assert t.decide(uptrend=True, entry_ok=True) == "enter"


def test_exit_signal_only_when_trend_breaks(cfg):
    t, _ = make_trader(cfg)
    t.enter(100.0, 2.0, T0)
    assert t.decide(True, True) is None
    assert t.decide(False, False) == "exit"


def test_daily_loss_limit_and_trade_cap(cfg):
    t, _ = make_trader(cfg)
    t.state.cash = t.state.day_start_equity * 0.85
    assert "Tagesverlust" in t.entry_blocked_reason(100.0)
    assert not t.enter(100.0, 2.0, T0 + 5)
    t2, _ = make_trader(cfg)
    t2.state.trades_today = cfg.risk.max_trades_per_day
    assert "Tageslimit" in t2.entry_blocked_reason(100.0)


def test_day_rollover_resets_counters(cfg):
    t, _ = make_trader(cfg)
    t.state.trades_today = 3
    t.state.cash = 9.5
    t.on_tick(100.0, T0 + DAY)
    assert t.state.trades_today == 0
    assert t.state.day_start_equity == pytest.approx(9.5)


def test_killswitch_liquidates_and_halts(cfg):
    t, sink = make_trader(cfg)
    assert t.enter(100.0, 2.0, T0)
    t.on_tick(55.0, T0 + 10)       # Kurs bricht stark ein, Stop wurde "verpasst"
    assert t.state.halted and not t.has_position
    assert [x["reason"] for x in sink.trades if x["side"] == "sell"] == ["killswitch"]
    assert "angehalten" in t.entry_blocked_reason(100.0)
    t.resume(55.0)
    assert not t.state.halted and t.state.peak_equity == pytest.approx(t.equity(55.0))


def test_too_small_account_skips_entry(cfg):
    cfg.start_equity = 4.0
    t, sink = make_trader(cfg, min_notional=5.0)
    t.state = TraderState.fresh(4.0)
    assert not t.enter(100.0, 2.0, T0)
    assert not t.has_position


# ---------- Backtest ----------
def test_backtest_catches_trend_without_lookahead(cfg):
    df = candles(down_up_down())
    res = run_backtest(df, cfg)
    m = res.metrics
    assert m["round_trips"] >= 1
    assert m["return_pct"] > 0
    d = add_indicators(df, cfg.strategy)
    first_buy = next(t for t in res.trades if t["side"] == "buy")
    j = int(d.index[d["ts"] == first_buy["ts"]][0])
    assert d["entry_ok"].iloc[j - 1]                                   # Signal kam von der Vorkerze ...
    assert first_buy["price"] == pytest.approx(d["open"].iloc[j] * (1 + cfg.costs.slippage))  # ... Kauf zur Eröffnung


def test_backtest_equity_matches_trade_ledger(cfg):
    res = run_backtest(candles(down_up_down()), cfg)
    realized = sum(t["pnl"] for t in res.trades if t["side"] == "sell")
    opened = res.trades[-1]["side"] == "buy"
    if not opened:
        assert res.metrics["end_equity"] == pytest.approx(cfg.start_equity + realized, abs=1e-4)  # Kennzahl ist auf 4 Stellen gerundet


def test_backtest_needs_enough_data(cfg):
    with pytest.raises(ValueError):
        run_backtest(candles([100.0] * 10), cfg)


def test_oos_split_includes_warmup(cfg):
    df = candles(down_up_down())
    part = split_out_of_sample(df, 0.3, min_bars(cfg.strategy))
    warm = min_bars(cfg.strategy)
    assert warm + 54 <= len(part) <= warm + 55   # 30 % von 180 Kerzen (+/- 1 durch Rundung) plus Vorlauf
    assert part["ts"].iloc[-1] == df["ts"].iloc[-1]


# ---------- Datenhilfen / Config / Store ----------
def test_drop_forming_candle():
    df = candles([1, 2, 3], start_ts=0)
    assert len(drop_forming_candle(df, TF_MS, now_ms=2 * TF_MS + 10)) == 2    # letzte läuft noch
    assert len(drop_forming_candle(df, TF_MS, now_ms=3 * TF_MS + 10)) == 3    # alle abgeschlossen


def test_default_config_file_is_valid():
    c = load_config()
    assert c.exchange in ("binance", "bitget", "mexc") and c.mode == "paper"


@pytest.mark.parametrize("mutate", [
    lambda c: setattr(c, "exchange", "kraken"),
    lambda c: setattr(c.risk, "position_fraction", 1.5),
    lambda c: setattr(c.strategy, "ema_fast", 60),
    lambda c: setattr(c, "symbol", "BTCUSDT"),
    lambda c: setattr(c.runtime, "history_bars", 20),
])
def test_config_validation_rejects_bad_values(mutate):
    c = Config()
    mutate(c)
    with pytest.raises(ConfigError):
        validate(c)


def test_store_roundtrip(tmp_path):
    s = Store(tmp_path / "x.sqlite3")
    s.kv_set("k", {"a": 1})
    s.add_trade(ts=1, side="buy", price=1.0, amount=2.0, cost=2.0, fee=0.1)
    s.add_equity(1, 10.0, 5.0)
    s.log("info", "hallo")
    assert s.kv_get("k") == {"a": 1} and s.kv_get("zzz", 7) == 7
    assert s.trades()[0]["side"] == "buy" and s.equity_series()[0]["equity"] == 10.0
    assert s.logs()[0]["msg"] == "hallo"
    s.close()
