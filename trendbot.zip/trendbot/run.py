#!/usr/bin/env python3
"""trendbot - Bedienung per Kommandozeile.

  python run.py check              Verbindung + Mindestordergröße deiner Börse prüfen
  python run.py fetch              Kurshistorie laden (für den Backtest)
  python run.py backtest           Strategie auf Historie testen (mit Gebühren)
  python run.py paper              Bot im Terminal laufen lassen (Simulation, echte Kurse)
  python run.py app                Bot + Browser-Dashboard (http://127.0.0.1:8787)
  python run.py live ...           ECHTES GELD (nur nach Backtest + Paper-Phase!)
"""
from __future__ import annotations

import argparse
import os
import sys
import threading

if sys.version_info < (3, 10):
    sys.exit(f"Python 3.10 oder neuer wird gebraucht (hier: {sys.version.split()[0]}). Bitte neueres Python installieren.")
try:
    from bot.backtest import format_metrics, plot_equity, run_backtest, split_out_of_sample
    from bot.config import DATA_DIR, ConfigError, load_config
    from bot.data import fetch_history, load_csv, make_public_exchange, make_synthetic, save_csv
    from bot.strategy import min_bars
except ModuleNotFoundError as e:
    sys.exit(f"Das Python-Paket '{e.name}' fehlt.\n"
             "1) Im Ordner 'trendbot' sein  2) virtuelle Umgebung aktivieren (siehe README, Schritt 0)  "
             "3) 'pip install -r requirements.txt' ausführen.")


def cmd_check(cfg, args):
    ex = make_public_exchange(cfg.exchange)
    ex.load_markets()
    m = ex.market(cfg.symbol)
    tick = ex.fetch_ticker(cfg.symbol)
    price = float(tick["last"])
    min_cost = (m.get("limits", {}).get("cost", {}) or {}).get("min")
    min_amt = (m.get("limits", {}).get("amount", {}) or {}).get("min")
    print(f"Börse        : {cfg.exchange}")
    print(f"Paar         : {cfg.symbol}  (Kurs {price:,.2f})")
    print(f"Mindestorder : {min_cost} {m['quote']} Wert  /  {min_amt} {m['base']} Menge")
    print(f"Gebühren     : Taker {m.get('taker')}  Maker {m.get('maker')}  (Konfig: {cfg.costs.fee_rate})")
    trade = cfg.start_equity * cfg.risk.position_fraction
    need = float(min_cost or cfg.costs.min_notional)
    print(f"Deine Order  : ca. {trade:.2f} {m['quote']} (start_equity x position_fraction)")
    if trade >= need * 1.02:
        print("OK: Mit deinem Startkapital ist eine Order möglich.")
    else:
        print(f"ZU KLEIN: Mindestens ca. {need * 1.02 / cfg.risk.position_fraction:.2f} USDT Startkapital nötig.")
    print("Hinweis: Die Gebühren in config.yaml solltest du mit deiner echten Gebührenstufe abgleichen.")


def cmd_fetch(cfg, args):
    ex = make_public_exchange(cfg.exchange)
    print(f"Lade {args.days} Tage {cfg.symbol} {cfg.timeframe} von {cfg.exchange} ...")
    df = fetch_history(ex, cfg.symbol, cfg.timeframe, args.days)
    save_csv(df, cfg.csv_path)
    print(f"{len(df)} Kerzen gespeichert: {cfg.csv_path}")


def cmd_backtest(cfg, args):
    if args.synthetic:
        df = make_synthetic(n=args.bars)
        print("ACHTUNG: synthetische Zufallsdaten - nur ein Technik-Test, sagt nichts über echte Märkte.\n")
    else:
        df = load_csv(cfg.csv_path)
    res = run_backtest(df, cfg, args.start_equity)
    print(format_metrics(res.metrics, f"Gesamter Zeitraum ({len(df)} Kerzen)"))
    if args.oos:
        oos = split_out_of_sample(df, args.oos, min_bars(cfg.strategy))
        print()
        print(format_metrics(run_backtest(oos, cfg, args.start_equity).metrics,
                             f"Nur letzte {int(args.oos * 100)} % (ungesehene Daten)"))
    if args.plot:
        out = DATA_DIR / "backtest.png"
        out.parent.mkdir(parents=True, exist_ok=True)
        print(f"\nDiagramm: {out}" if plot_equity(res, out) else "\n(matplotlib fehlt - kein Diagramm)")
    print("\nVergangenheit ist keine Garantie. Gebühren/Slippage sind Annahmen aus config.yaml.")


def confirm_live(args) -> None:
    if not args.i_understand_the_risk:
        sys.exit("Live-Modus braucht --i-understand-the-risk (echtes Geld, Verluste möglich).")
    if os.getenv("TRENDBOT_CONFIRM_LIVE") == "YES":
        return
    if not sys.stdin.isatty():
        sys.exit("Kein Terminal für die Bestätigung. Setze TRENDBOT_CONFIRM_LIVE=YES für Server-Betrieb.")
    if input("LIVE-MODUS mit echtem Geld. Zum Starten tippe exakt:  LIVE   > ").strip() != "LIVE":
        sys.exit("Abgebrochen.")


def build_runner(cfg):
    from bot.runner import Runner
    from bot.store import Store

    return Runner(cfg, store=Store(cfg.db_path, echo=True))


def check_connection(runner) -> None:
    try:
        runner.ex.fetch_ticker(runner.cfg.symbol)
        print(f"Börsenverbindung OK ({runner.cfg.exchange}, {runner.cfg.symbol}).")
    except Exception as e:
        print(f"WARNUNG: Keine Verbindung zu {runner.cfg.exchange}: {str(e)[:160]}\n"
              "Der Bot versucht es weiter. Prüfe Internet/VPN/Firewall - manche Länder/Netze sperren einzelne Börsen.")


def cmd_headless(cfg, args):
    runner = build_runner(cfg)
    check_connection(runner)
    print(f"Bot läuft ({cfg.mode}, {cfg.exchange} {cfg.symbol} {cfg.timeframe}). Beenden mit Strg+C.")
    try:
        runner.run_forever()
    except KeyboardInterrupt:
        runner.stop()
        print("\nBeendet. Offene Positionen bleiben bestehen und werden beim nächsten Start weitergeführt.")


def cmd_app(cfg, args):
    import socket
    import webbrowser

    import uvicorn

    from bot.dashboard import create_app

    port = cfg.runtime.dashboard_port
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", port)) == 0:
            sys.exit(f"Port {port} ist schon belegt - läuft der Bot noch in einem anderen Terminal? "
                     "Dort mit Strg+C beenden oder 'dashboard_port' in config.yaml ändern.")
    runner = build_runner(cfg)
    check_connection(runner)
    threading.Thread(target=runner.run_forever, daemon=True, name="bot").start()
    url = f"http://127.0.0.1:{port}"
    print(f"\nDashboard: {url}   (Beenden mit Strg+C)\n")
    if not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    try:
        uvicorn.run(create_app(runner), host="127.0.0.1", port=port, log_level="warning")
    finally:
        runner.stop()


def main():
    ap = argparse.ArgumentParser(description="trendbot", formatter_class=argparse.RawDescriptionHelpFormatter,
                                 epilog=__doc__)
    ap.add_argument("--config", default=None, help="Pfad zu einer anderen config.yaml")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("check")
    p = sub.add_parser("fetch"); p.add_argument("--days", type=int, default=730)
    p = sub.add_parser("backtest")
    p.add_argument("--synthetic", action="store_true", help="künstliche Daten (Technik-Test)")
    p.add_argument("--bars", type=int, default=3000)
    p.add_argument("--oos", type=float, default=0.3, help="Anteil ungesehener Daten für Zweittest (0 = aus)")
    p.add_argument("--start-equity", type=float, default=None)
    p.add_argument("--plot", action="store_true")
    sub.add_parser("paper")
    for name in ("live", "app"):
        p = sub.add_parser(name)
        p.add_argument("--i-understand-the-risk", action="store_true")
        if name == "app":
            p.add_argument("--mode", choices=("paper", "live"), default=None)
            p.add_argument("--no-browser", action="store_true", help="Browser nicht automatisch öffnen")
    args = ap.parse_args()

    try:
        cfg = load_config(args.config)
    except (ConfigError, FileNotFoundError) as e:
        sys.exit(f"Konfigurationsfehler: {e}")

    if args.cmd == "paper":
        cfg.mode = "paper"
    elif args.cmd == "live":
        cfg.mode = "live"
    elif args.cmd == "app" and args.mode:
        cfg.mode = args.mode
    if cfg.mode == "live" and args.cmd in ("live", "app"):
        confirm_live(args)

    handler = {"check": cmd_check, "fetch": cmd_fetch, "backtest": cmd_backtest, "paper": cmd_headless,
               "live": cmd_headless, "app": cmd_app}[args.cmd]
    try:
        handler(cfg, args)
    except Exception as e:
        try:
            import ccxt
        except ImportError:
            raise e
        if isinstance(e, ccxt.NetworkError):
            sys.exit(f"Keine Verbindung zur Börse ({cfg.exchange}). Internet/VPN/Firewall prüfen und erneut versuchen.\n"
                     f"Technische Details: {str(e)[:200]}")
        if isinstance(e, ccxt.AuthenticationError):
            sys.exit("Die Börse hat die API-Keys abgelehnt. Keys, Passphrase (Bitget) und IP-Whitelist in .env prüfen.")
        raise


if __name__ == "__main__":
    main()
