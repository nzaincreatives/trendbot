"""Risiko-Regeln: Positionsgröße (das "Hochskalieren") und Stop-Berechnung."""
from __future__ import annotations

from .config import Costs, RiskCfg


def stop_price(entry_price: float, atr: float, mult: float) -> float:
    """Stop-Loss unter dem Einstieg. Nie unter 50 % vom Einstieg (Schutz vor Ausreißer-ATR)."""
    return max(entry_price - mult * atr, entry_price * 0.5)


def size_quote(equity: float, cash: float, price: float, atr: float, risk: RiskCfg, costs: Costs) -> float:
    """Wie viel USDT sollen in die nächste Position?

    Skalierung: ein fester Anteil des AKTUELLEN Kontostands -> wächst mit Gewinnen,
    schrumpft mit Verlusten (Zinseszins, kein Martingale, kein Hebel).

    Begrenzt durch:
      1. position_fraction x Kontostand
      2. max_risk_per_trade: Verlust am Stop darf höchstens X % vom Konto sein
      3. verfügbares Bargeld (inkl. Puffer für Gebühren und Slippage)
    """
    if equity <= 0 or cash <= 0 or price <= 0:
        return 0.0
    by_fraction = equity * risk.position_fraction
    stop_pct = (price - stop_price(price, atr, risk.stop_atr_mult)) / price
    by_risk = equity * risk.max_risk_per_trade / stop_pct if stop_pct > 0 else 0.0
    by_cash = cash / (1.0 + costs.fee_rate + costs.slippage)
    return max(0.0, min(by_fraction, by_risk, by_cash))
