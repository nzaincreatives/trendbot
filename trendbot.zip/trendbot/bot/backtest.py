"""Backtest: spielt historische Kerzen durch denselben Trader-Code wie im Live-Betrieb.

Ablauf pro Kerze i:
  1. Signal von Kerze i-1 wird zum ERÖFFNUNGSKURS von Kerze i ausgeführt (kein Blick in die Zukunft)
  2. Stop-Loss wird mit dem Tief der Kerze i geprüft (bei Gap unter den Stop: Ausführung zur Eröffnung)
  3. Am Schlusskurs: Kontostand mitschreiben, neues Signal berechnen
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from .broker import PaperBroker
from .config import Config
from .store import MemoryStore
from .strategy import add_indicators, min_bars
from .trader import Trader, TraderState


@dataclass
class BacktestResult:
    metrics: dict
    equity: pd.DataFrame  # Spalten: ts, equity, close
    trades: list[dict]


def _max_drawdown(eq: pd.Series) -> float:
    if eq.empty:
        return 0.0
    peak = eq.cummax()
    return float(((eq / peak) - 1.0).min() * 100.0)


def run_backtest(df: pd.DataFrame, cfg: Config, start_equity: float | None = None) -> BacktestResult:
    start_equity = float(start_equity if start_equity is not None else cfg.start_equity)
    d = add_indicators(df, cfg.strategy).reset_index(drop=True)
    warm = min_bars(cfg.strategy)
    if len(d) <= warm + 2:
        raise ValueError(f"Zu wenige Kerzen ({len(d)}). Mindestens {warm + 3} nötig.")

    broker = PaperBroker(cfg.costs.fee_rate, cfg.costs.slippage, cfg.costs.min_notional)
    sink = MemoryStore()
    trader = Trader(cfg, broker, sink, TraderState.fresh(start_equity))
    trader.state.armed = not bool(d["uptrend"].iloc[warm - 1])  # nur auf frische Trendwechsel einsteigen
    trader.state.initialized = True

    curve: list[tuple[int, float, float]] = []
    pending: tuple[str, float] | None = None
    bars_in_pos = 0

    for i in range(warm, len(d)):
        row = d.iloc[i]
        ts = int(row["ts"])
        o, lo, c = float(row["open"]), float(row["low"]), float(row["close"])

        if pending is not None:
            action, atr = pending
            pending = None
            if action == "exit" and trader.has_position:
                trader.exit(o, ts, "signal")
            elif action == "enter" and not trader.has_position:
                trader.on_tick(o, ts)
                trader.enter(o, atr, ts)

        if trader.has_position:
            trader.check_stop(lo, o, ts)

        trader.on_tick(c, ts)
        if trader.has_position:
            bars_in_pos += 1
        curve.append((ts, trader.equity(c), c))

        action = trader.decide(bool(row["uptrend"]), bool(row["entry_ok"]))
        if action:
            pending = (action, float(row["atr"]))

    eq = pd.DataFrame(curve, columns=["ts", "equity", "close"])
    metrics = compute_metrics(eq, sink.trades, start_equity, bars_in_pos, trader.state.halted, trader.state.halt_reason)
    return BacktestResult(metrics, eq, sink.trades)


def compute_metrics(eq: pd.DataFrame, trades: list[dict], start_equity: float, bars_in_pos: int,
                    halted: bool = False, halt_reason: str = "") -> dict:
    end_equity = float(eq["equity"].iloc[-1])
    sells = [t for t in trades if t["side"] == "sell"]
    wins = [t["pnl"] for t in sells if t["pnl"] > 0]
    losses = [t["pnl"] for t in sells if t["pnl"] <= 0]
    gross_win, gross_loss = sum(wins), -sum(losses)
    bh = (float(eq["close"].iloc[-1]) / float(eq["close"].iloc[0]) - 1.0) * 100.0
    return {
        "start_equity": round(start_equity, 4),
        "end_equity": round(end_equity, 4),
        "return_pct": round((end_equity / start_equity - 1.0) * 100.0, 2),
        "buy_and_hold_pct": round(bh, 2),
        "max_drawdown_pct": round(_max_drawdown(eq["equity"]), 2),
        "round_trips": len(sells),
        "win_rate_pct": round(len(wins) / len(sells) * 100.0, 1) if sells else None,
        "profit_factor": round(gross_win / gross_loss, 2) if gross_loss > 0 else None,
        "fees_paid": round(sum(t["fee"] for t in trades), 4),
        "time_in_market_pct": round(bars_in_pos / len(eq) * 100.0, 1),
        "bars": len(eq),
        "halted": halted,
        "halt_reason": halt_reason,
    }


def split_out_of_sample(df: pd.DataFrame, frac: float, warm: int) -> pd.DataFrame:
    """Letzte `frac` der Daten (mit Vorlauf für die Indikatoren) - zum Test auf ungesehenen Daten."""
    cut = int(len(df) * (1.0 - frac))
    return df.iloc[max(0, cut - warm):].reset_index(drop=True)


def format_metrics(m: dict, title: str = "") -> str:
    def f(v, suffix=""):
        return "-" if v is None else f"{v}{suffix}"

    lines = [
        f"--- {title} ---" if title else "---",
        f"Start -> Ende            : {m['start_equity']} -> {m['end_equity']} USDT ({m['return_pct']:+.2f} %)",
        f"Kaufen & Halten (Vgl.)  : {m['buy_and_hold_pct']:+.2f} %",
        f"Max. Drawdown           : {m['max_drawdown_pct']:.2f} %",
        f"Abgeschlossene Trades   : {m['round_trips']}",
        f"Trefferquote            : {f(m['win_rate_pct'], ' %')}",
        f"Profit-Faktor           : {f(m['profit_factor'])}",
        f"Gezahlte Gebühren       : {m['fees_paid']} USDT",
        f"Zeit im Markt           : {m['time_in_market_pct']} %",
    ]
    if m["halted"]:
        lines.append(f"HINWEIS: Bot wurde angehalten ({m['halt_reason']})")
    return "\n".join(lines)


def plot_equity(res: BacktestResult, path, title: str = "") -> bool:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return False
    eq = res.equity
    x = pd.to_datetime(eq["ts"], unit="ms")
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(x, eq["equity"] / eq["equity"].iloc[0], label="Bot", linewidth=1.6)
    ax.plot(x, eq["close"] / eq["close"].iloc[0], label="Kaufen & Halten", linewidth=1.0, alpha=0.7)
    ax.set_title(title or "Kontoverlauf (normiert auf 1.0)")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)
    return True
