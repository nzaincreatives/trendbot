"""Trader: führt Buch über Guthaben/Position und setzt alle Risiko-Regeln durch.

Derselbe Code läuft im Backtest, im Paper-Modus und live. Der Trader führt sein EIGENES Guthaben
(start_equity + Gewinne/Verluste). Liegen auf dem Börsenkonto mehr als 10 USDT, rührt der Bot
den Rest nicht an.
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

from .broker import OrderRejected
from .config import Config
from .risk import size_quote, stop_price


def utc_day(ts_ms: int) -> str:
    return datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


@dataclass
class TraderState:
    cash: float
    peak_equity: float
    day_start_equity: float
    position: dict | None = None
    armed: bool = True
    initialized: bool = False
    day: str = ""
    trades_today: int = 0
    halted: bool = False
    halt_reason: str = ""
    last_candle_ts: int = 0
    last_signal: str = ""

    @classmethod
    def fresh(cls, start_equity: float) -> "TraderState":
        return cls(cash=start_equity, peak_equity=start_equity, day_start_equity=start_equity)

    @classmethod
    def from_dict(cls, d: dict) -> "TraderState":
        known = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
        return cls(**known)

    def to_dict(self) -> dict:
        return asdict(self)


class Trader:
    def __init__(self, cfg: Config, broker, sink, state: TraderState | None = None, live: bool = False):
        self.cfg = cfg
        self.broker = broker
        self.sink = sink  # Store oder MemoryStore
        self.state = state or TraderState.fresh(cfg.start_equity)
        self.live = live

    # ---------- Hilfen ----------
    @property
    def has_position(self) -> bool:
        return self.state.position is not None

    def equity(self, price: float) -> float:
        pos = self.state.position
        return self.state.cash + (pos["amount"] * price if pos else 0.0)

    def log(self, level: str, msg: str, ts: int | None = None) -> None:
        self.sink.log(level, msg, ts)

    def save(self) -> None:
        self.sink.kv_set("trader_state", self.state.to_dict())

    # ---------- Wächter ----------
    def halt(self, reason: str, ts: int | None = None) -> None:
        if not self.state.halted:
            self.log("error", f"BOT ANGEHALTEN: {reason}", ts)
        self.state.halted = True
        self.state.halt_reason = reason

    def resume(self, price: float) -> None:
        """Manuelles Fortsetzen. Setzt Höchststand und Tagesstart auf den aktuellen Stand zurück."""
        eq = self.equity(price)
        self.state.halted = False
        self.state.halt_reason = ""
        self.state.peak_equity = eq
        self.state.day_start_equity = eq
        self.log("warn", "Bot manuell fortgesetzt (Höchststand zurückgesetzt).")

    def on_tick(self, price: float, ts: int) -> None:
        """Bei jedem Preis-Update: Tageswechsel, Höchststand, Kill-Switch."""
        s = self.state
        eq = self.equity(price)
        day = utc_day(ts)
        if day != s.day:
            s.day = day
            s.day_start_equity = eq
            s.trades_today = 0
        if eq > s.peak_equity:
            s.peak_equity = eq
        if not s.halted and s.peak_equity > 0:
            dd = 1.0 - eq / s.peak_equity
            if dd >= self.cfg.risk.max_drawdown_halt:
                self.halt(f"Kill-Switch: {dd * 100:.1f} % unter Höchststand", ts)
                if self.has_position:
                    self.exit(price, ts, "killswitch")

    def entry_blocked_reason(self, price: float) -> str | None:
        s, r = self.state, self.cfg.risk
        if s.halted:
            return f"angehalten ({s.halt_reason})"
        if s.trades_today >= r.max_trades_per_day:
            return f"Tageslimit {r.max_trades_per_day} Einstiege erreicht"
        if s.day_start_equity > 0 and self.equity(price) <= s.day_start_equity * (1.0 - r.daily_loss_limit):
            return f"Tagesverlust-Limit {r.daily_loss_limit * 100:.0f} % erreicht"
        return None

    # ---------- Signale ----------
    def decide(self, uptrend: bool, entry_ok: bool) -> str | None:
        """Aus Trend-Zustand eine Aktion machen. Nur aufrufen, wenn eine NEUE Kerze abgeschlossen ist."""
        s = self.state
        if not uptrend:
            s.armed = True  # Trend hat gedreht -> neuer Einstieg wieder erlaubt
        if self.has_position:
            return "exit" if not uptrend else None
        if s.armed and entry_ok:
            return "enter"
        return None

    # ---------- Orders ----------
    def enter(self, price: float, atr: float, ts: int) -> bool:
        reason = self.entry_blocked_reason(price)
        if reason:
            self.log("info", f"Einstieg übersprungen: {reason}", ts)
            return False
        s, cfg = self.state, self.cfg
        cash = s.cash
        if self.live:
            cash = min(cash, self.broker.free_quote())
        q = size_quote(self.equity(price), cash, price, atr, cfg.risk, cfg.costs)
        if q < self.broker.min_notional_value() * 1.02:
            self.log("warn", f"Einstieg übersprungen: Positionsgröße {q:.2f} USDT unter Mindestgröße "
                             f"({self.broker.min_notional_value():.2f} USDT)", ts)
            return False
        try:
            fill = self.broker.market_buy(q, price)
        except OrderRejected as e:
            self.log("warn", f"Kauf abgelehnt: {e}", ts)
            return False
        except Exception as e:  # unklarer Orderstatus -> lieber anhalten als doppelt kaufen
            if self.live:
                self.halt(f"Unklarer Kauf-Status ({e!r}). Bitte Börse prüfen, dann manuell fortsetzen.", ts)
                return False
            raise
        s.cash -= fill.net_quote
        s.position = {
            "entry_price": fill.price,
            "amount": fill.amount,
            "stop": stop_price(fill.price, atr, self.cfg.risk.stop_atr_mult),
            "entry_ts": ts,
            "cost": fill.net_quote,
            "atr": atr,
        }
        s.trades_today += 1
        self.sink.add_trade(ts=ts, side="buy", price=fill.price, amount=fill.amount, cost=fill.cost,
                            fee=fill.fee, pnl=None, reason="signal")
        self.log("info", f"KAUF {fill.amount:.6f} @ {fill.price:.2f} (Stop {s.position['stop']:.2f})", ts)
        return True

    def exit(self, price: float, ts: int, reason: str) -> bool:
        s = self.state
        pos = s.position
        if not pos:
            return False
        try:
            fill = self.broker.market_sell(pos["amount"], price)
        except OrderRejected as e:
            self.halt(f"Verkauf abgelehnt: {e}", ts)
            return False
        proceeds = fill.net_quote
        pnl = proceeds - pos["cost"]
        s.cash += proceeds
        s.position = None
        self.sink.add_trade(ts=ts, side="sell", price=fill.price, amount=fill.amount, cost=fill.cost,
                            fee=fill.fee, pnl=pnl, reason=reason)
        self.log("info", f"VERKAUF {fill.amount:.6f} @ {fill.price:.2f} ({reason}) PnL {pnl:+.4f} USDT", ts)
        return True

    def check_stop(self, bar_low: float, ref_price: float, ts: int) -> bool:
        """Stop prüfen. Backtest: bar_low = Tief der Kerze, ref_price = Eröffnung (Gap-Schutz).
        Live: beides = aktueller Kurs. Nach einem Stop wartet der Bot auf eine Trendumkehr."""
        pos = self.state.position
        if not pos or bar_low > pos["stop"]:
            return False
        fill_price = min(ref_price, pos["stop"])
        ok = self.exit(fill_price, ts, "stop")
        if ok:
            self.state.armed = False
        return ok

    def close_now(self, price: float, ts: int | None = None) -> bool:
        """Manuelles Schließen (Dashboard-Button). Hält den Bot danach NICHT an."""
        ts = ts or int(time.time() * 1000)
        ok = self.exit(price, ts, "manuell")
        if ok:
            self.state.armed = False
        return ok
