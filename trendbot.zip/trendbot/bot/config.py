"""Konfiguration laden und prüfen."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"

SUPPORTED_EXCHANGES = ("binance", "bitget", "mexc")


@dataclass
class Costs:
    fee_rate: float = 0.001
    slippage: float = 0.0005
    min_notional: float = 5.0


@dataclass
class StrategyCfg:
    ema_fast: int = 20
    ema_slow: int = 50
    atr_period: int = 14
    min_atr_pct: float = 0.4


@dataclass
class RiskCfg:
    position_fraction: float = 0.90
    stop_atr_mult: float = 3.0
    max_risk_per_trade: float = 0.05
    daily_loss_limit: float = 0.10
    max_drawdown_halt: float = 0.30
    max_trades_per_day: int = 4


@dataclass
class RuntimeCfg:
    poll_seconds: int = 30
    history_bars: int = 300
    sandbox: bool = False
    dashboard_port: int = 8787


@dataclass
class Config:
    exchange: str = "binance"
    symbol: str = "BTC/USDT"
    timeframe: str = "4h"
    mode: str = "paper"
    start_equity: float = 10.0
    costs: Costs = field(default_factory=Costs)
    strategy: StrategyCfg = field(default_factory=StrategyCfg)
    risk: RiskCfg = field(default_factory=RiskCfg)
    runtime: RuntimeCfg = field(default_factory=RuntimeCfg)

    @property
    def db_path(self) -> Path:
        safe = self.symbol.replace("/", "-")
        return DATA_DIR / f"{self.mode}_{self.exchange}_{safe}_{self.timeframe}.sqlite3"

    @property
    def csv_path(self) -> Path:
        safe = self.symbol.replace("/", "-")
        return DATA_DIR / f"{self.exchange}_{safe}_{self.timeframe}.csv"


class ConfigError(ValueError):
    pass


def _section(cls, raw: dict | None):
    raw = raw or {}
    unknown = set(raw) - set(cls.__dataclass_fields__)
    if unknown:
        raise ConfigError(f"Unbekannte Einstellung(en) in {cls.__name__}: {sorted(unknown)}")
    return cls(**raw)


def validate(cfg: Config) -> Config:
    if cfg.exchange not in SUPPORTED_EXCHANGES:
        raise ConfigError(f"exchange muss eines von {SUPPORTED_EXCHANGES} sein, nicht '{cfg.exchange}'")
    if cfg.mode not in ("paper", "live"):
        raise ConfigError("mode muss 'paper' oder 'live' sein")
    if "/" not in cfg.symbol:
        raise ConfigError("symbol muss wie 'BTC/USDT' aussehen")
    if cfg.start_equity <= 0:
        raise ConfigError("start_equity muss > 0 sein")
    s, r, c = cfg.strategy, cfg.risk, cfg.costs
    if not (1 <= s.ema_fast < s.ema_slow):
        raise ConfigError("ema_fast muss kleiner als ema_slow sein (und >= 1)")
    if s.atr_period < 2:
        raise ConfigError("atr_period muss >= 2 sein")
    if not (0 < r.position_fraction <= 1):
        raise ConfigError("position_fraction muss zwischen 0 und 1 liegen (kein Hebel!)")
    if r.stop_atr_mult <= 0:
        raise ConfigError("stop_atr_mult muss > 0 sein")
    for name in ("max_risk_per_trade", "daily_loss_limit", "max_drawdown_halt"):
        if not (0 < getattr(r, name) < 1):
            raise ConfigError(f"{name} muss zwischen 0 und 1 liegen")
    if not (0 <= c.fee_rate < 0.05 and 0 <= c.slippage < 0.05):
        raise ConfigError("fee_rate/slippage wirken unrealistisch (erwartet z. B. 0.001)")
    if cfg.runtime.history_bars < s.ema_slow * 3:
        raise ConfigError("history_bars sollte mindestens das 3-fache von ema_slow sein")
    return cfg


def load_config(path: str | os.PathLike | None = None) -> Config:
    path = Path(path) if path else ROOT / "config.yaml"
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    top = {k: raw[k] for k in ("exchange", "symbol", "timeframe", "mode", "start_equity") if k in raw}
    unknown = set(raw) - set(top) - {"costs", "strategy", "risk", "runtime"}
    if unknown:
        raise ConfigError(f"Unbekannte Einstellung(en) in config.yaml: {sorted(unknown)}")
    cfg = Config(
        **top,
        costs=_section(Costs, raw.get("costs")),
        strategy=_section(StrategyCfg, raw.get("strategy")),
        risk=_section(RiskCfg, raw.get("risk")),
        runtime=_section(RuntimeCfg, raw.get("runtime")),
    )
    return validate(cfg)


def load_keys(exchange: str) -> dict:
    """API-Keys aus .env / Umgebung. Gibt nur Felder zurück, die gesetzt sind."""
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
    p = exchange.upper()
    keys = {
        "apiKey": os.getenv(f"{p}_API_KEY", "").strip(),
        "secret": os.getenv(f"{p}_API_SECRET", "").strip(),
    }
    pw = os.getenv(f"{p}_API_PASSPHRASE", "").strip()
    if pw:
        keys["password"] = pw
    return {k: v for k, v in keys.items() if v}
