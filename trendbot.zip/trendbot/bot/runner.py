"""Runner: die Endlosschleife für Paper- und Live-Betrieb (läuft auch im Hintergrund der App)."""
from __future__ import annotations

import threading
import time

from .broker import CcxtBroker, PaperBroker
from .config import Config, load_keys
from .data import drop_forming_candle, fetch_recent, make_public_exchange
from .store import Store
from .strategy import add_indicators, min_bars
from .trader import Trader, TraderState


class Runner:
    def __init__(self, cfg: Config, public_exchange=None, broker=None, store: Store | None = None, clock=None):
        self.cfg = cfg
        self.clock = clock or time.time  # austauschbar für Tests
        self.live = cfg.mode == "live"
        self.store = store or Store(cfg.db_path)
        self.ex = public_exchange or make_public_exchange(cfg.exchange)
        self.tf_ms = self.ex.parse_timeframe(cfg.timeframe) * 1000
        if broker is None:
            if self.live:
                broker = CcxtBroker(cfg.exchange, cfg.symbol, load_keys(cfg.exchange), cfg.runtime.sandbox,
                                    cfg.costs.fee_rate)
            else:
                broker = PaperBroker(cfg.costs.fee_rate, cfg.costs.slippage, cfg.costs.min_notional)
        self.broker = broker
        saved = self.store.kv_get("trader_state")
        fresh = saved is None
        state = TraderState.from_dict(saved) if saved else TraderState.fresh(cfg.start_equity)
        self.trader = Trader(cfg, broker, self.store, state, live=self.live)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.last_price = 0.0
        self.last_poll = 0
        self.last_error = ""
        self.fail_count = 0
        self.preflight(fresh)

    # ---------- Start-Prüfungen ----------
    def preflight(self, fresh: bool) -> None:
        if fresh:
            self.store.log("info", f"Neustart im Modus '{self.cfg.mode}' mit {self.cfg.start_equity} USDT "
                                   f"({self.cfg.exchange} {self.cfg.symbol} {self.cfg.timeframe})")
        if not self.live:
            return
        free_q = self.broker.free_quote()
        if fresh and free_q < self.cfg.start_equity:
            raise RuntimeError(f"Auf der Börse sind nur {free_q:.2f} {self.broker.quote} frei, "
                               f"start_equity ist aber {self.cfg.start_equity}.")
        pos = self.trader.state.position
        if pos:
            free_b = self.broker.free_base()
            if free_b < pos["amount"] * 0.98:
                self.trader.halt(f"Gespeicherte Position ({pos['amount']}) nicht auf der Börse gefunden "
                                 f"(frei: {free_b}). Bitte prüfen.")
        min_n = self.broker.min_notional_value()
        if fresh and self.cfg.start_equity * self.cfg.risk.position_fraction < min_n * 1.02:
            raise RuntimeError(f"Mit {self.cfg.start_equity} USDT ist keine Order möglich: Börsen-Minimum {min_n} USDT.")

    # ---------- Ein Durchlauf ----------
    def step(self) -> None:
        cfg, tr = self.cfg, self.trader
        with self.lock:
            df = fetch_recent(self.ex, cfg.symbol, cfg.timeframe, cfg.runtime.history_bars)
            price = float(df["close"].iloc[-1])
            now_ms = int(self.clock() * 1000)
            self.last_price, self.last_poll = price, now_ms
            closed = drop_forming_candle(df, self.tf_ms, now_ms)
            if len(closed) < min_bars(cfg.strategy):
                self.store.log("warn", f"Zu wenig Kerzen ({len(closed)}), warte ...")
                return
            ind = add_indicators(closed, cfg.strategy)
            row = ind.iloc[-1]
            s = tr.state

            tr.on_tick(price, now_ms)
            if tr.has_position:
                tr.check_stop(price, price, now_ms)

            new_ts = int(row["ts"])
            if new_ts > s.last_candle_ts:
                if not s.initialized:
                    s.armed = not bool(row["uptrend"])  # nur auf frische Trendwechsel einsteigen
                    s.initialized = True
                    self.store.log("info", "Start: warte auf den nächsten frischen Trendwechsel nach oben."
                                   if not s.armed else "Start: kein Aufwärtstrend, Einstieg wird beobachtet.")
                else:
                    action = tr.decide(bool(row["uptrend"]), bool(row["entry_ok"]))
                    if action == "exit":
                        tr.exit(price, now_ms, "signal")
                    elif action == "enter":
                        tr.enter(price, float(row["atr"]), now_ms)
                s.last_signal = "Aufwärtstrend" if bool(row["uptrend"]) else "Kein Aufwärtstrend"
                s.last_candle_ts = new_ts
                self.store.add_equity(now_ms, tr.equity(price), price)
            tr.save()
            self.last_error = ""
            self.fail_count = 0

    def run_forever(self) -> None:
        self.store.log("info", "Bot-Schleife gestartet.")
        last_snap = 0
        while not self.stop_event.is_set():
            try:
                self.step()
                if time.time() - last_snap > 300:  # alle 5 Min. ein Punkt für die Kurve
                    with self.lock:
                        self.store.add_equity(int(time.time() * 1000), self.trader.equity(self.last_price), self.last_price)
                    last_snap = time.time()
            except Exception as e:  # Netzwerkfehler etc. dürfen den Bot nicht beenden
                self.fail_count += 1
                self.last_error = f"{type(e).__name__}: {e}"
                self.store.log("error", f"Fehler im Durchlauf: {self.last_error}")
            wait = self.cfg.runtime.poll_seconds if self.fail_count == 0 else min(300, 10 * self.fail_count)
            self.stop_event.wait(wait)
        self.store.log("info", "Bot-Schleife beendet.")

    def stop(self) -> None:
        self.stop_event.set()

    # ---------- Steuerung (Dashboard) ----------
    def halt(self, reason: str = "Manuell gestoppt") -> None:
        with self.lock:
            self.trader.halt(reason)
            self.trader.save()

    def resume(self) -> None:
        with self.lock:
            self.trader.resume(self.last_price or 0.0)
            self.trader.save()

    def close_position(self) -> bool:
        with self.lock:
            if not self.last_price:
                return False
            ok = self.trader.close_now(self.last_price)
            self.trader.save()
            return ok

    def status(self) -> dict:
        with self.lock:
            s, cfg, price = self.trader.state, self.cfg, self.last_price
            eq = self.trader.equity(price) if price else s.cash
            pos = None
            if s.position:
                p = s.position
                value = p["amount"] * price
                pos = {**p, "value": value, "unrealized_pnl": value - p["cost"],
                       "unrealized_pct": (value / p["cost"] - 1.0) * 100.0 if p["cost"] else 0.0}
            return {
                "mode": cfg.mode, "exchange": cfg.exchange, "symbol": cfg.symbol, "timeframe": cfg.timeframe,
                "price": price, "equity": eq, "cash": s.cash, "start_equity": cfg.start_equity,
                "return_pct": (eq / cfg.start_equity - 1.0) * 100.0,
                "peak_equity": s.peak_equity,
                "drawdown_pct": (1.0 - eq / s.peak_equity) * 100.0 if s.peak_equity else 0.0,
                "position": pos, "armed": s.armed, "halted": s.halted, "halt_reason": s.halt_reason,
                "last_signal": s.last_signal, "last_candle_ts": s.last_candle_ts,
                "trades_today": s.trades_today, "last_poll": self.last_poll, "last_error": self.last_error,
                "params": {
                    "ema": f"{cfg.strategy.ema_fast}/{cfg.strategy.ema_slow}",
                    "position_fraction": cfg.risk.position_fraction,
                    "stop_atr_mult": cfg.risk.stop_atr_mult,
                    "daily_loss_limit": cfg.risk.daily_loss_limit,
                    "max_drawdown_halt": cfg.risk.max_drawdown_halt,
                },
            }
