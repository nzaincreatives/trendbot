"""Marktdaten: Kerzen von der Börse holen (öffentlich, ohne Keys) + synthetische Testdaten."""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import pandas as pd

COLUMNS = ["ts", "open", "high", "low", "close", "volume"]


def make_public_exchange(exchange_id: str):
    import ccxt

    cls = getattr(ccxt, exchange_id)
    return cls({"enableRateLimit": True})


def ohlcv_to_df(rows: list[list]) -> pd.DataFrame:
    df = pd.DataFrame(rows, columns=COLUMNS)
    df["ts"] = df["ts"].astype("int64")
    df = df.drop_duplicates("ts").sort_values("ts").reset_index(drop=True)
    return df


def fetch_history(exchange, symbol: str, timeframe: str, days: int, page: int = 500) -> pd.DataFrame:
    """Holt `days` Tage Kerzen seitenweise. Funktioniert ohne API-Key."""
    tf_ms = exchange.parse_timeframe(timeframe) * 1000
    now_ms = int(time.time() * 1000)
    since = now_ms - days * 86_400_000
    rows: list[list] = []
    guard = 0
    while since < now_ms and guard < 2000:
        guard += 1
        batch = exchange.fetch_ohlcv(symbol, timeframe, since=since, limit=page)
        if not batch:
            break
        rows.extend(batch)
        last = batch[-1][0]
        if last + tf_ms <= since:  # kein Fortschritt
            break
        since = last + tf_ms
    if not rows:
        raise RuntimeError(f"Keine Kerzen für {symbol} {timeframe} erhalten.")
    return ohlcv_to_df(rows)


def fetch_recent(exchange, symbol: str, timeframe: str, bars: int) -> pd.DataFrame:
    return ohlcv_to_df(exchange.fetch_ohlcv(symbol, timeframe, limit=bars))


def drop_forming_candle(df: pd.DataFrame, tf_ms: int, now_ms: int | None = None) -> pd.DataFrame:
    """Entfernt die letzte Kerze, falls sie noch nicht abgeschlossen ist."""
    now_ms = int(time.time() * 1000) if now_ms is None else now_ms
    if len(df) and df["ts"].iloc[-1] + tf_ms > now_ms:
        return df.iloc[:-1].reset_index(drop=True)
    return df


def save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def load_csv(path: Path) -> pd.DataFrame:
    if not Path(path).exists():
        raise FileNotFoundError(f"{path} fehlt. Erst 'python run.py fetch' ausführen (oder --synthetic nutzen).")
    df = pd.read_csv(path)
    return df[COLUMNS].astype({"ts": "int64"}).reset_index(drop=True)


def make_synthetic(n: int = 3000, tf_hours: int = 4, seed: int = 7, start_price: float = 50_000.0) -> pd.DataFrame:
    """Künstliche Kurse mit wechselnden Phasen (Aufwärts/Abwärts/Seitwärts).

    NUR zum Testen der Technik. Sagt nichts über echte Märkte aus.
    """
    rng = np.random.default_rng(seed)
    regimes = [(0.0007, 0.010), (-0.0006, 0.013), (0.0000, 0.006)]  # (Drift, Vola) pro Kerze
    closes = np.empty(n)
    price = start_price
    i = 0
    while i < n:
        drift, vol = regimes[rng.integers(0, len(regimes))]
        length = int(rng.integers(80, 400))
        for _ in range(min(length, n - i)):
            price *= float(np.exp(rng.normal(drift, vol)))
            closes[i] = price
            i += 1
    opens = np.concatenate([[start_price], closes[:-1]])
    span = np.abs(rng.normal(0, 0.004, n)) * closes
    highs = np.maximum(opens, closes) + span
    lows = np.minimum(opens, closes) - span
    step = tf_hours * 3_600_000
    t0 = 1_600_000_000_000
    ts = t0 + np.arange(n, dtype="int64") * step
    return pd.DataFrame(
        {"ts": ts, "open": opens, "high": highs, "low": lows, "close": closes, "volume": rng.uniform(10, 100, n)}
    )
