"""Strategie: EMA-Trendfolge mit Volatilitätsfilter. Nur Long, nur Spot, kein Hebel.

Regeln (alle auf ABGESCHLOSSENEN Kerzen):
  * Aufwärtstrend  : schnelle EMA > langsame EMA
  * Einstieg erlaubt: Aufwärtstrend UND Schlusskurs > langsame EMA UND ATR% >= min_atr_pct
  * Ausstieg       : Trend dreht (schnelle EMA <= langsame EMA) oder Stop-Loss (Einstieg - n x ATR)
  * Nach einem Stop-Loss wartet der Bot, bis der Trend einmal gedreht hat ("Re-Arm"),
    damit er nicht in derselben Seitwärtsphase immer wieder reinläuft.
"""
from __future__ import annotations

import pandas as pd

from .config import StrategyCfg


def min_bars(p: StrategyCfg) -> int:
    """So viele Kerzen braucht es mindestens, bis die Indikatoren verlässlich sind."""
    return max(p.ema_slow, p.atr_period) * 3


def add_indicators(df: pd.DataFrame, p: StrategyCfg) -> pd.DataFrame:
    d = df.copy()
    c = d["close"].astype(float)
    d["ema_fast"] = c.ewm(span=p.ema_fast, adjust=False).mean()
    d["ema_slow"] = c.ewm(span=p.ema_slow, adjust=False).mean()
    prev_close = c.shift(1)
    true_range = pd.concat(
        [d["high"] - d["low"], (d["high"] - prev_close).abs(), (d["low"] - prev_close).abs()], axis=1
    ).max(axis=1)
    d["atr"] = true_range.ewm(alpha=1.0 / p.atr_period, adjust=False).mean()
    d["atr_pct"] = d["atr"] / c * 100.0
    d["uptrend"] = d["ema_fast"] > d["ema_slow"]
    d["entry_ok"] = d["uptrend"] & (c > d["ema_slow"]) & (d["atr_pct"] >= p.min_atr_pct)
    return d
