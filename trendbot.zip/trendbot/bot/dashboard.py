"""Browser-Dashboard (lokal). Startet mit:  python run.py app

Sicherheit:
  * lauscht nur auf 127.0.0.1 (nicht aus dem Netzwerk erreichbar)
  * Steuer-Buttons (POST) brauchen ein Token, das nur in der eigenen Seite steht
    -> fremde Webseiten im Browser können keine Aktionen auslösen
"""
from __future__ import annotations

import secrets
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse, Response

from .runner import Runner

STATIC = Path(__file__).resolve().parent / "static" / "index.html"


def create_app(runner: Runner) -> FastAPI:
    app = FastAPI(title="trendbot", docs_url=None, redoc_url=None, openapi_url=None)
    token = secrets.token_urlsafe(16)

    def need_token(x_token: str = Header(default="")):
        if not secrets.compare_digest(x_token, token):
            raise HTTPException(status_code=403, detail="Ungültiges Token")

    @app.get("/", response_class=HTMLResponse)
    def index():
        return STATIC.read_text(encoding="utf-8").replace("__TOKEN__", token)

    @app.get("/favicon.ico", include_in_schema=False)
    def favicon():
        return Response(status_code=204)

    @app.get("/api/status")
    def status():
        return runner.status()

    @app.get("/api/equity")
    def equity():
        return runner.store.equity_series(1500)

    @app.get("/api/trades")
    def trades():
        return runner.store.trades(50)

    @app.get("/api/logs")
    def logs():
        return runner.store.logs(60)

    @app.post("/api/halt", dependencies=[Depends(need_token)])
    def halt():
        runner.halt()
        return {"ok": True}

    @app.post("/api/resume", dependencies=[Depends(need_token)])
    def resume():
        runner.resume()
        return {"ok": True}

    @app.post("/api/close", dependencies=[Depends(need_token)])
    def close():
        return {"ok": runner.close_position()}

    return app
