"""Broker: PaperBroker (Simulation) und CcxtBroker (echte Orders bei Binance/Bitget/MEXC).

Beide haben dieselbe Schnittstelle, damit Backtest, Paper und Live exakt denselben Trader-Code nutzen.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass


class OrderRejected(Exception):
    """Order wurde bewusst nicht abgeschickt oder von der Börse abgelehnt (z. B. zu klein)."""


@dataclass
class Fill:
    price: float      # durchschnittlicher Ausführungspreis
    amount: float     # Menge in Basiswährung (Kauf: netto erhalten, Verkauf: verkauft)
    cost: float       # Brutto-Volumen in USDT (amount_brutto * price)
    fee: float        # Gebühr, umgerechnet in USDT (nur zur Anzeige)
    net_quote: float  # Kauf: tatsächlich bezahlte USDT | Verkauf: tatsächlich erhaltene USDT


class PaperBroker:
    """Simulierte Ausführung zu übergebenem Kurs plus Slippage und Gebühr."""

    name = "paper"

    def __init__(self, fee_rate: float = 0.001, slippage: float = 0.0005, min_notional: float = 5.0):
        self.fee_rate = fee_rate
        self.slippage = slippage
        self.min_notional = min_notional

    def min_notional_value(self) -> float:
        return self.min_notional

    def free_quote(self) -> float:
        return math.inf  # das Guthaben führt der Trader selbst

    def market_buy(self, quote_amount: float, price: float) -> Fill:
        if quote_amount < self.min_notional:
            raise OrderRejected(f"Order {quote_amount:.2f} USDT unter Mindestgröße {self.min_notional:.2f} USDT")
        px = price * (1.0 + self.slippage)
        cost = quote_amount / (1.0 + self.fee_rate)
        return Fill(price=px, amount=cost / px, cost=cost, fee=cost * self.fee_rate, net_quote=quote_amount)

    def market_sell(self, amount: float, price: float) -> Fill:
        if amount <= 0:
            raise OrderRejected("Verkaufsmenge ist 0")
        px = price * (1.0 - self.slippage)
        cost = amount * px
        if cost < self.min_notional:
            raise OrderRejected(f"Verkauf {cost:.2f} USDT unter Mindestgröße {self.min_notional:.2f} USDT")
        fee = cost * self.fee_rate
        return Fill(price=px, amount=amount, cost=cost, fee=fee, net_quote=cost - fee)


class CcxtBroker:
    """Echte Market-Orders über ccxt. ACHTUNG: bewegt echtes Geld.

    Wichtige Details:
      * Mindestordergröße kommt von der Börse (limits.cost.min / limits.amount.min).
      * Verkauft wird nie mehr als das, was wirklich frei verfügbar ist (Gebühren können in der
        gekauften Coin-Menge abgezogen werden, z. B. bei Binance ohne BNB-Gebühr).
      * Kauf wird mit 0,5 % Puffer gerechnet, damit das Guthaben bei Kursbewegung reicht.
    """

    name = "live"

    def __init__(self, exchange_id: str, symbol: str, keys: dict, sandbox: bool = False, fee_rate: float = 0.001,
                 exchange=None):
        if exchange is None:
            import ccxt

            if not keys.get("apiKey") or not keys.get("secret"):
                raise RuntimeError(f"Für Live-Handel fehlen API-Keys für {exchange_id} in der .env-Datei.")
            exchange = getattr(ccxt, exchange_id)(
                {**keys, "enableRateLimit": True, "options": {"defaultType": "spot"}}
            )
            if sandbox:
                exchange.set_sandbox_mode(True)
        self.ex = exchange
        self.symbol = symbol
        self.fee_rate = fee_rate
        self.ex.load_markets()
        self.market = self.ex.market(symbol)
        self.base = self.market["base"]
        self.quote = self.market["quote"]

    # ---- Infos ----
    def min_notional_value(self) -> float:
        m = (self.market.get("limits", {}).get("cost", {}) or {}).get("min")
        return float(m) if m else 0.0

    def min_amount_value(self) -> float:
        m = (self.market.get("limits", {}).get("amount", {}) or {}).get("min")
        return float(m) if m else 0.0

    def _free(self, currency: str) -> float:
        bal = self.ex.fetch_balance()
        return float((bal.get("free") or {}).get(currency) or 0.0)

    def free_quote(self) -> float:
        return self._free(self.quote)

    def free_base(self) -> float:
        return self._free(self.base)

    # ---- Orders ----
    def market_buy(self, quote_amount: float, price: float) -> Fill:
        min_cost = self.min_notional_value()
        if quote_amount < min_cost:
            raise OrderRejected(f"Order {quote_amount:.2f} {self.quote} unter Börsen-Minimum {min_cost:.2f}")
        amount = float(self.ex.amount_to_precision(self.symbol, quote_amount * 0.995 / price))
        if amount <= 0 or amount < self.min_amount_value():
            raise OrderRejected(f"Menge {amount} unter Börsen-Minimum {self.min_amount_value()}")
        if amount * price < min_cost:
            raise OrderRejected(f"Orderwert {amount * price:.2f} nach Rundung unter Minimum {min_cost:.2f}")
        order = self.ex.create_order(self.symbol, "market", "buy", amount, price)
        return self._fill(order, "buy", price)

    def market_sell(self, amount: float, price: float) -> Fill:
        free = self.free_base()
        amount = float(self.ex.amount_to_precision(self.symbol, min(amount, free)))
        if amount <= 0 or amount < self.min_amount_value():
            raise OrderRejected(f"Verkaufsmenge {amount} {self.base} zu klein oder nicht verfügbar (frei: {free})")
        if amount * price < self.min_notional_value():
            raise OrderRejected(
                f"Verkaufswert {amount * price:.2f} unter Börsen-Minimum {self.min_notional_value():.2f} - "
                "Position muss ggf. manuell an der Börse geschlossen werden"
            )
        order = self.ex.create_order(self.symbol, "market", "sell", amount)
        return self._fill(order, "sell", price)

    def _fill(self, order: dict, side: str, price_hint: float) -> Fill:
        for _ in range(8):  # manche Börsen liefern die Füllung erst beim Nachfragen
            if order.get("status") == "closed" and order.get("filled"):
                break
            time.sleep(0.5)
            order = self.ex.fetch_order(order["id"], self.symbol)
        filled = float(order.get("filled") or 0.0)
        if filled <= 0:
            raise RuntimeError(f"Order {order.get('id')} ohne Füllung (Status: {order.get('status')}). Börse prüfen!")
        avg = float(order.get("average") or order.get("price") or price_hint)
        cost = float(order.get("cost") or filled * avg)
        fees = order.get("fees") or ([order["fee"]] if order.get("fee") else [])
        fee_quote_ccy = fee_base_ccy = fee_value = 0.0
        known = False
        for f in fees:
            c = float(f.get("cost") or 0.0)
            cur = f.get("currency")
            if cur == self.quote:
                fee_quote_ccy += c
                fee_value += c
                known = True
            elif cur == self.base:
                fee_base_ccy += c
                fee_value += c * avg
                known = True
        if not known:  # z. B. Gebühr in BNB oder nicht gemeldet -> Schätzung
            fee_value = cost * self.fee_rate
            fee_quote_ccy = fee_value
        if side == "buy":
            return Fill(avg, filled - fee_base_ccy, cost, fee_value, cost + fee_quote_ccy)
        return Fill(avg, filled, cost, fee_value, cost - fee_quote_ccy)
