"""Speicher: SQLite für Trades, Kontoverlauf, Log und Bot-Zustand (überlebt Neustarts)."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path


class MemoryStore:
    """Wird im Backtest genutzt: merkt sich Trades im RAM, schreibt nichts auf die Platte."""

    def __init__(self):
        self.trades: list[dict] = []

    def add_trade(self, **t):
        self.trades.append(t)

    def add_equity(self, ts, equity, price):
        pass

    def log(self, level, msg, ts=None):
        pass

    def kv_get(self, key, default=None):
        return default

    def kv_set(self, key, value):
        pass


class Store:
    def __init__(self, path: Path, echo: bool = False):
        self.echo = echo  # True: Meldungen zusätzlich im Terminal ausgeben
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.executescript(
                """
                CREATE TABLE IF NOT EXISTS trades(
                    id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, side TEXT, price REAL,
                    amount REAL, cost REAL, fee REAL, pnl REAL, reason TEXT);
                CREATE TABLE IF NOT EXISTS equity(ts INTEGER, equity REAL, price REAL);
                CREATE TABLE IF NOT EXISTS logs(ts INTEGER, level TEXT, msg TEXT);
                CREATE TABLE IF NOT EXISTS kv(key TEXT PRIMARY KEY, value TEXT);
                """
            )

    @staticmethod
    def _now() -> int:
        return int(time.time() * 1000)

    def add_trade(self, ts, side, price, amount, cost, fee, pnl=None, reason=""):
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO trades(ts,side,price,amount,cost,fee,pnl,reason) VALUES(?,?,?,?,?,?,?,?)",
                (ts, side, price, amount, cost, fee, pnl, reason),
            )

    def add_equity(self, ts, equity, price):
        with self._lock, self._db:
            self._db.execute("INSERT INTO equity(ts,equity,price) VALUES(?,?,?)", (ts, equity, price))

    def log(self, level, msg, ts=None):
        with self._lock, self._db:
            self._db.execute("INSERT INTO logs(ts,level,msg) VALUES(?,?,?)", (ts or self._now(), level, msg))
        if self.echo:
            try:
                print(f"[{time.strftime('%H:%M:%S')}] {level.upper():5} {msg}", flush=True)
            except UnicodeEncodeError:
                pass

    def kv_get(self, key, default=None):
        with self._lock:
            row = self._db.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
        return json.loads(row["value"]) if row else default

    def kv_set(self, key, value):
        with self._lock, self._db:
            self._db.execute(
                "INSERT INTO kv(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value)),
            )

    def _rows(self, sql, args=()):
        with self._lock:
            return [dict(r) for r in self._db.execute(sql, args).fetchall()]

    def trades(self, limit=100):
        return self._rows("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,))

    def equity_series(self, limit=2000):
        rows = self._rows("SELECT ts,equity,price FROM equity ORDER BY ts DESC LIMIT ?", (limit,))
        return rows[::-1]

    def logs(self, limit=100):
        return self._rows("SELECT * FROM logs ORDER BY rowid DESC LIMIT ?", (limit,))

    def close(self):
        with self._lock:
            self._db.close()
