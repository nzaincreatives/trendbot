"""trendbot - kleiner Spot-Trendfolge-Bot (Binance / Bitget / MEXC über ccxt)."""
