# trendbot – kleiner Spot-Trendfolge-Bot (Binance · Bitget · MEXC)

Ein Bot für kleine Beträge (Start: 10 USDT), der mit einer einfachen Trendstrategie handelt und seine
Positionsgröße automatisch an den Kontostand anpasst. Du bedienst ihn wie eine App im Browser.

> **Ehrlich vorab:** Das ist ein Lern- und Testprojekt, kein Einkommensplan. Gewinne sind nicht garantiert,
> Verluste sind möglich. Bei 10 USDT sind selbst gute Ergebnisse in Euro klein. Keine Anlageberatung.
> In Deutschland können Krypto-Gewinne steuerlich relevant sein – die Trades stehen im Dashboard und in `data/`.

## Was der Bot macht

| Thema | Umsetzung |
|---|---|
| Märkte | Spot, nur Long, **kein Hebel**. Eine Börse und ein Paar gleichzeitig (Standard: Binance, BTC/USDT, 4h) |
| Strategie | EMA-Trendfolge (20/50) + Mindest-Schwankung (ATR). Einstieg nur bei frischem Trendwechsel nach oben |
| Ausstieg | Trend dreht **oder** Stop-Loss bei Einstieg − 3 × ATR |
| „Hochskalieren" | Jeder Trade nutzt **90 % des aktuellen Kontostands** (Zinseszins). Gewinne vergrößern die nächste Position, Verluste verkleinern sie |
| Schutz | Max. 5 % Kontorisiko pro Trade · Tagesverlust-Limit −10 % · **Kill-Switch bei −30 %** vom Höchststand (verkauft alles und hält an) · max. 4 Einstiege pro Tag |
| Dein Kapital | Der Bot führt sein **eigenes Guthaben** (`start_equity` + Gewinne/Verluste). Liegt mehr auf deinem Börsenkonto, rührt er den Rest nicht an |

## Schritt 0 – Installation (einmalig)

1. **Python 3.11 oder neuer** installieren (python.org). Unter Windows beim Installer „Add Python to PATH" anhaken.
2. Den Ordner `trendbot` entpacken und im Terminal hineinwechseln.
3. Virtuelle Umgebung und Pakete:

```bash
# Mac / Linux
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Windows (PowerShell)
py -m venv .venv ; .venv\Scripts\activate
pip install -r requirements.txt
```

Jedes Mal, wenn du ein neues Terminal öffnest, vorher `source .venv/bin/activate` (Windows: `.venv\Scripts\activate`).

## Schritt 1 – Börse prüfen (kein Konto, keine Keys nötig)

```bash
python run.py check
```

Zeigt Kurs, **Mindestordergröße** und Gebühren deiner Börse und sagt dir, ob 10 USDT reichen.
Die Gebühren in `config.yaml` (`costs.fee_rate`) gleichst du mit deiner echten Gebührenstufe ab.

Börse wechseln: in `config.yaml` `exchange: binance | bitget | mexc` setzen.

## Schritt 2 – Backtest (Strategie auf Historie testen)

```bash
python run.py fetch --days 730      # 2 Jahre Kerzen laden
python run.py backtest --plot       # Test inkl. Gebühren; Diagramm landet in data/backtest.png
```

Du bekommst zwei Blöcke: den **gesamten Zeitraum** und die **letzten 30 % als „ungesehene" Daten**.

So liest du es:
- **Rendite** gegen „Kaufen & Halten" vergleichen und den **Max. Drawdown** ansehen (wie tief ging es zwischendurch runter?).
- **Profit-Faktor** über 1 heißt: Gewinne waren größer als Verluste. Ein Wert knapp über 1 reicht nach Gebühren oft nicht.
- Wenn der ungesehene Teil deutlich schlechter ist als der Rest, ist die Strategie vermutlich nur auf die Vergangenheit „passend".
- Wenige Trades (unter ca. 20) sind statistisch dünn. Ein guter Backtest ist **kein** Versprechen.
- Werte in `config.yaml` nicht so lange drehen, bis der Backtest schön aussieht – das ist Überanpassung.

`python run.py backtest --synthetic` testet nur die Technik mit Zufallsdaten (ohne Internet möglich).

## Schritt 3 – Paper-Trading (Simulation mit echten Kursen, kein Geld, keine Keys)

```bash
python run.py app
```

Dann im Browser **http://127.0.0.1:8787** öffnen. Du siehst Kontostand, Kurs, Position, Verlauf, Trades und Protokoll.
Buttons: **Bot anhalten**, **Fortsetzen**, **Position jetzt schließen**.

- Beim Start steigt der Bot **nicht mitten in einen laufenden Trend** ein, sondern wartet auf den nächsten frischen Wechsel nach oben.
- Bei 4h-Kerzen gibt es nur wenige Trades. Lass den Paper-Modus **mindestens 4 Wochen** laufen und vergleiche mit dem Backtest.
- Der Zustand liegt in `data/` (SQLite). Du kannst das Terminal schließen und später weitermachen; offene Positionen werden fortgeführt.
- Ohne Browser: `python run.py paper` (nur Terminal).

### Wenn `python run.py app` nicht startet

| Meldung / Symptom | Ursache und Lösung |
|---|---|
| `python` wird nicht gefunden | Windows: `py run.py app` · Mac/Linux: `python3 run.py app` |
| „Das Python-Paket '…' fehlt" | Nicht im Ordner `trendbot`, virtuelle Umgebung nicht aktiv oder `pip install -r requirements.txt` fehlt (Schritt 0) |
| „Python 3.10 oder neuer wird gebraucht" | Neueres Python installieren |
| „Port 8787 ist schon belegt" | Der Bot läuft noch in einem anderen Terminal (dort Strg+C) oder `dashboard_port` in `config.yaml` ändern |
| „WARNUNG: Keine Verbindung zu binance" | Internet/VPN/Firewall prüfen. Manche Länder oder Netze sperren einzelne Börsen: dann `exchange: bitget` oder `mexc` probieren |
| Browser öffnet sich nicht | `http://127.0.0.1:8787` von Hand öffnen (oder `--no-browser` weglassen) |

Im Terminal erscheinen jetzt alle Bot-Meldungen (Käufe, Verkäufe, Fehler). Schick mir bei Problemen den **genauen Text** aus dem Terminal.

## Schritt 4 – API-Key anlegen (erst nach erfolgreicher Paper-Phase)

1. Bei der Börse einen API-Key erstellen. **Nur „Spot Trading" und Lesen aktivieren, „Abheben/Withdraw" NICHT.**
2. Wenn möglich **IP-Whitelist** auf deine IP setzen (bei Heim-Internet ändert sich die IP ab und zu).
3. `.env.example` nach `.env` kopieren und die Werte eintragen (Bitget braucht zusätzlich die Passphrase).
4. Keys **nie** in Chats, Screenshots oder Git teilen. `.env` steht in `.gitignore`.

## Schritt 5 – Live mit Minimalbetrag

1. Genau den Betrag auf das Spot-Konto legen, den du verlieren könntest (z. B. 10 USDT) und `start_equity` entsprechend setzen.
2. Starten:

```bash
python run.py app --mode live --i-understand-the-risk
```

Du musst zur Bestätigung `LIVE` tippen. Das Dashboard zeigt oben deutlich **„LIVE – echtes Geld"**.
Beim allerersten Live-Trade danebensitzen und mit der Börsen-App abgleichen (Ausführungspreis, Menge, Gebühr).

## Lokal oder Server?

| | Pro | Contra |
|---|---|---|
| **Eigener PC** | kostenlos, einfach | nicht 24/7 (Standby, Updates, WLAN) – **ohne laufenden Bot gibt es keinen Stop-Loss** |
| **Raspberry Pi / Mini-PC** | günstig, 24/7 | Heimnetz-/Stromausfall, Einrichtung |
| **VPS** | stabil, feste IP für die Whitelist | laufende Kosten, die bei 10 USDT den Gewinn übersteigen können |

Empfehlung: erst lokal (Backtest + Paper), später ggf. auf einen kleinen VPS. Auf einem Server:
`TRENDBOT_CONFIRM_LIVE=YES python run.py live --i-understand-the-risk` (z. B. in `tmux`/`systemd`) und das Dashboard
nur per SSH-Tunnel öffnen: `ssh -L 8787:127.0.0.1:8787 user@server` – den Port nie ins Internet freigeben.

## Wichtige Grenzen (bitte lesen)

- **Der Stop-Loss wird vom Bot geprüft (alle `poll_seconds`), nicht an der Börse hinterlegt.** Ist der Bot aus oder offline, schützt dich nichts.
- Der Verkauf erfolgt zum Marktpreis. Bei schnellen Bewegungen kann er schlechter als der Stop sein.
- **Mindestordergröße:** Rutscht die Position unter das Börsen-Minimum, lehnt die Börse den Verkauf ab. Der Bot hält dann an und meldet es – dann manuell an der Börse schließen.
- Bei Unklarheit nach einer Kauf-Order (z. B. Netzwerkfehler) hält der Bot **an**, statt blind nachzukaufen. Börse prüfen, dann „Fortsetzen".
- Mit 10 USDT und ~0,1 % Gebühr pro Seite fressen Kosten einen spürbaren Teil kleiner Gewinne. `python run.py check` zeigt die Werte deiner Börse.
- **Die Live-Order-Anbindung ist gegen simulierte Börsen getestet, nicht gegen echte Konten.** Binance, Bitget und MEXC verhalten sich bei Details (Gebührenwährung, Mindestgrößen, Market-Buy) unterschiedlich. Deshalb: erst Paper, dann winziger Live-Betrag unter Aufsicht. Bei Bitget/MEXC besonders vorsichtig sein.
- Es gibt keine Garantie, dass die Strategie profitabel ist – nicht im Backtest, nicht im Paper-Modus, nicht live.

## Einstellungen (`config.yaml`)

| Einstellung | Bedeutung |
|---|---|
| `exchange`, `symbol`, `timeframe` | Börse, Paar, Kerzenlänge |
| `start_equity` | dein Startkapital in USDT |
| `costs.*` | Gebühr, Slippage, Mindestgröße (Paper) |
| `strategy.*` | EMA-Längen, ATR, Mindest-Schwankung |
| `risk.position_fraction` | Anteil des Kontostands pro Trade (max. 1.0, kein Hebel) |
| `risk.stop_atr_mult` | Stop-Abstand in ATR |
| `risk.daily_loss_limit`, `risk.max_drawdown_halt` | Tageslimit und Kill-Switch |

Ungültige Werte werden beim Start mit einer verständlichen Meldung abgelehnt.

## Dateien

```
run.py              Kommandozeile (check, fetch, backtest, paper, app, live)
config.yaml         alle Einstellungen
bot/strategy.py     Indikatoren und Signale
bot/risk.py         Positionsgröße und Stop
bot/trader.py       Buchführung, Limits, Kill-Switch (gleicher Code für Backtest/Paper/Live)
bot/broker.py       PaperBroker und CcxtBroker (echte Orders)
bot/backtest.py     Backtest ohne Blick in die Zukunft
bot/runner.py       Endlosschleife, speichert Zustand
bot/dashboard.py    Browser-App (nur localhost, Steuer-Buttons per Token geschützt)
tests/              33 automatische Tests:  python -m pytest
```

## Nächste Ausbaustufen (wenn alles stabil läuft)

Stop-Loss als Börsen-Order, Telegram-Benachrichtigung bei Trades/Halt, mehrere Paare, Parameter-Test über mehrere Zeiträume (Walk-Forward).
